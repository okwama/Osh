const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

// Get all notices
exports.getAllNotices = async (req, res) => {
  try {
    const notices = await prisma.noticeBoard.findMany({
      orderBy: { createdAt: 'desc' },
      select: {
        id: true,
        title: true,
        content: true,
        createdAt: true,
        updatedAt: true,
      },
    });
    res.status(200).json(notices);
  } catch (error) {
    console.error('Error fetching notices:', error);
    // Send more detailed error information in development
    if (process.env.NODE_ENV === 'development') {
      res.status(500).json({ 
        error: 'Internal server error',
        details: error.message 
      });
    } else {
      res.status(500).json({ error: 'Internal server error' });
    }
  }
};

// Get a single notice by ID
exports.getNoticeById = async (req, res) => {
  try {
    const id = Number(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ error: 'Invalid notice ID' });
    }

    const notice = await prisma.noticeBoard.findUnique({
      where: { id },
      select: {
        id: true,
        title: true,
        content: true,
        createdAt: true,
        updatedAt: true,
      },
    });

    if (!notice) {
      return res.status(404).json({ error: 'Notice not found' });
    }

    res.status(200).json(notice);
  } catch (error) {
    console.error('Error fetching notice:', error);
    // Send more detailed error information in development
    if (process.env.NODE_ENV === 'development') {
      res.status(500).json({ 
        error: 'Internal server error',
        details: error.message 
      });
    } else {
      res.status(500).json({ error: 'Internal server error' });
    }
  }
};
